﻿using CarRacing.Models.Maps.Contracts;
using CarRacing.Models.Racers.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarRacing.Models.Maps
{
    public class Map : IMap
    {
        public string StartRace(IRacer racerOne, IRacer racerTwo)
        {
            if (!racerOne.IsAvailable() && !racerTwo.IsAvailable())
            {
                return "Race cannot be completed because both racers are not available!";
            }

            if (!racerOne.IsAvailable())
            {
                return $"{racerTwo.Username} wins the race! {racerOne.Username} was not available to race!";
            }

            if (!racerTwo.IsAvailable())
            {
                return $"{racerOne.Username} wins the race! {racerTwo.Username} was not available to race!";
            }

            racerOne.Race();
            racerTwo.Race();

            double oneMult;
            double twoMult;

            if (racerOne.RacingBehavior == "strict")
            {
                oneMult = 1.2;
            }
            else
            {
                oneMult = 1.1;
            }

            if (racerTwo.RacingBehavior == "strict")
            {
                twoMult = 1.2;
            }
            else
            {
                twoMult = 1.1;
            }

            double chanceOfWinningOne = racerOne.Car.HorsePower * racerOne.DrivingExperience * oneMult;
            double chanceOfWinningTwo = racerTwo.Car.HorsePower * racerTwo.DrivingExperience * twoMult;
            string winner;

            if (chanceOfWinningOne > chanceOfWinningTwo)
            {
                winner = racerOne.Username;
            }
            else
            {
                winner = racerTwo.Username;
            }

            return $"{racerOne.Username} has just raced against {racerTwo.Username}! {winner} is the winner!";
        }
    }
}
