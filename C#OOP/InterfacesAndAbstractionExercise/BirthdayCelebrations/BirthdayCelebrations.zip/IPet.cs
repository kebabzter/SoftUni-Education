﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebrations
{
    interface IPet
    {
        public string Name { get; set; }
    }
}
