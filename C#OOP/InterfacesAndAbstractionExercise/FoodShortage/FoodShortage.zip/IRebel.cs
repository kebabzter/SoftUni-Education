﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    interface IRebel
    {
        public string Group { get; set; }
    }
}
