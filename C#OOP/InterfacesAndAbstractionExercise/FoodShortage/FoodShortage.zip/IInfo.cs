﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    interface IInfo
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}
