﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => "Server=DESKTOP-9FQGRBP;Database=BookShop;Integrated Security=True;";
    }
}
