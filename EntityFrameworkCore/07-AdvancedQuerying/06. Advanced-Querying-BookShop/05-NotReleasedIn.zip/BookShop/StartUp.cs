﻿namespace BookShop
{
    using BookShop.Models.Enums;
    using Data;
    using Initializer;
    using System;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);

            //2. Age Restriction
            //  string ar = Console.ReadLine();
            //  string result = GetBooksByAgeRestriction(db, ar);
            //  Console.WriteLine(result);

            //3. Golden Books
            // string result = GetGoldenBooks(db);
            // Console.WriteLine(result);

            //4. Books by Price
            //string result = GetBooksByPrice(db);
            // Console.WriteLine(result);

            //5. Not Released In
            int year = int.Parse(Console.ReadLine());
            string result = GetBooksNotReleasedIn(db,year);
            Console.WriteLine(result);
        }

        //5. Not Released In
        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            StringBuilder sb = new StringBuilder();
            var booksTitle = context.Books
                .Where(b => b.ReleaseDate.HasValue && b.ReleaseDate.Value.Year!=year)
                .OrderBy(b => b.BookId)
                .Select(b => b.Title)
                .ToArray();

            foreach (var book in booksTitle)
            {
                sb.AppendLine(book);
            }
            return sb.ToString().TrimEnd();
        }

        //4. Books by Price
        public static string GetBooksByPrice(BookShopContext context)
        {
            StringBuilder sb = new StringBuilder();
            var booksTitle = context.Books
                .Where(b => b.Price > 40)
                .OrderByDescending(b => b.Price)
                .Select(b => new
                {
                    Title = b.Title,
                    Price=b.Price
                })
                .ToArray();

            foreach (var book in booksTitle)
            {
                sb.AppendLine($"{book.Title} - ${book.Price:f2}");
            }
            return sb.ToString().TrimEnd();
        }


        //3. Golden Books
        public static string GetGoldenBooks(BookShopContext context)
        {
            StringBuilder sb = new StringBuilder();
            var booksTitle = context.Books
                .Where(b => b.EditionType==EditionType.Gold && b.Copies < 5000)
                .OrderBy(b => b.BookId)
                .Select(b => b.Title)
                .ToArray();

            foreach (var title in booksTitle)
            {
                sb.AppendLine(title);
            }
            return sb.ToString().TrimEnd();
        }

        //2. Age Restriction
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            StringBuilder sb = new StringBuilder();
            AgeRestriction ar=Enum.Parse<AgeRestriction>(command,true);
            var booksTitle = context.Books
                .Where(b => b.AgeRestriction == ar)
                .OrderBy(b => b.Title)
                .Select(b => b.Title)
                .ToArray();

            foreach (var title in booksTitle)
            {
                sb.AppendLine(title);
            }
            return sb.ToString().TrimEnd();
        }
    }
}
