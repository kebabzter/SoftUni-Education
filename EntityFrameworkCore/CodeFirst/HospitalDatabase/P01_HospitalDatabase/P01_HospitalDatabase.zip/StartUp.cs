﻿using P01_HospitalDatabase.Data;

namespace P01_HospitalDatabase
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            /* HospitalContext dbContext = new HospitalContext();
              dbContext.Database.EnsureCreated();
              Console.WriteLine("Create DB");
              dbContext.Database.EnsureDeleted();*/
        }
    }
}
