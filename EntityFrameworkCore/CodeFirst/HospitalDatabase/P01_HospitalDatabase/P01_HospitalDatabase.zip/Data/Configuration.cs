﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    public static class Configuration
    {
        public const string CONNECTION_STRING = @"Server=DESKTOP-9FQGRBP;Database=HospitalDatabase;Integrated Security=True;";
    }
}
